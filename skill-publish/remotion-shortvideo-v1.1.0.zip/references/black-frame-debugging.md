# 闪屏 / 黑帧排查手册（2026-10-17 五轮实测复盘）

> 场景：用户看视频说"闪 / 有闪屏"。本手册是某中文宣传片项目连续五轮排查后沉淀的方法论，覆盖"先分清闪的类型 → 帧级取证 → 按类型修复 → 交叉验证"全链路。

## 1. 先分清两类"闪"（修法完全不同）

| 类型 | 特征 | 根因 | 修法 |
|---|---|---|---|
| (a) 确定性构图 bug | 多次渲染，异常帧号**固定不变** | 某帧构图逻辑：fadeOut 太早、Scene 整卡入场空帧、交叉淡入透明窗 | 改代码可根除 |
| (b) 非确定性渲染竞态 | 多次渲染，异常帧号**每次不同** | headless Chrome `Page.captureScreenshot` 偶尔在页面绘制提交前取到未绘制的黑色表面 | 改视频内容无效，走第 4 节修复管线 |

**第一步永远是量化，不是改代码。** 判断方法：连渲两次，扫出的异常帧号对不上 → 竞态（b）；对得上 → 构图 bug（a）。

## 2. 症状与根因速查表

| 症状 | 根因 | 修法 |
|---|---|---|
| 场景切换处"闪空" | Scene 开头整卡 fade/spring 入场（opacity 0→1 + 位移），前段满屏 → 衔接帧整卡不可见 | 卡片恒 opacity 1 满屏，仅首内容轻缩放入场 |
| 某个场景整段黑屏 | inline data URI 的 key 与代码引用对不上 → `url(undefined)` | 对齐 key；验证时量屏幕区亮度 |
| 孤立随机黑帧（帧号每次渲染都不同） | Chrome 截帧竞态。Remotion 源码自证：`screenshot-task.js` 注释 "0.1% framedrop when rendering under memory pressure" | 第 4 节管线 |
| 半绘制帧（整帧变暗约 50%） | 竞态 + "检测重试"补丁落在绘制中间态 | 不要用重试补丁（见第 5 节） |
| "有声音没画面"空窗 | 为旁白拉长段落后，场景内硬编码 fadeOut 帧窗口没同步 | 改段长时同步检查所有 interpolate/spring 窗口 |
| `<Img>` 截图个别帧缺失 | Remotion `Img` 内部 delayRender + decode 竞态 | 换 inline data URI + `background-image` 的 div（降低概率，不根除黑帧） |

## 3. 验证方法论（最重要，且验证工具本身有三个坑）

**必须帧级取证，禁止单帧抽样**——只在场景边界抽 1-2 帧"看"，天然漏掉随机闪（竞态每次掉不同帧）。标准动作：**全片逐帧扫描 + 定点帧准确复测**。

三个实测工具坑（每一个都造成过误报，导致"修了其实没修"的假象）：

1. **`ffmpeg -ss <秒>` 时间定位取帧系统性晚 1 帧**（PTS 取整）。想看第 703 帧实际取到 704 → "看着正常"全是假象。**必须用 `select=eq(n,X)` 按帧号抽取**。
2. **limited-range YUV（黑 = Y16 而非 0）**，`format=gray` 不做量程扩展，顺序扫描里黑帧均值 ~14-16。黑帧阈值必须按 **<20** 设（邻帧 >25），按 <10 设会漏掉场景边界的黑帧。
3. **批量 `signalstats,metadata=print` 扫描帧索引错位**，会产出假阳性/假阴性。最可靠的是 rawvideo 裸流顺序扫描（绝对帧序）。

金标准命令：

```bash
FF=node_modules/@remotion/compositor-darwin-x64/ffmpeg

# A. 全片顺序扫描（帧准确）：32x32 灰度裸流，Python 逐帧均值
$FF -hide_banner -i video.mp4 -vf "scale=32:32,format=gray" -pix_fmt gray -f rawvideo - \
  | python3 -c "import sys; d=sys.stdin.buffer.read(); fr=1024; n=len(d)//fr; m=[sum(d[i*fr:(i+1)*fr])/fr for i in range(n)]; print(n, min(m)); print([i for i in range(1,n-1) if m[i]<20 and m[i-1]>25 and m[i+1]>25])"

# B. 定点帧准确复测（量程扩展，黑=0.0）
$FF -hide_banner -i video.mp4 -vf "select=eq(n\,703)" -frames:v 1 -f rawvideo -pix_fmt gray - \
  | python3 -c "import sys; d=sys.stdin.buffer.read(); print(sum(d)/max(1,len(d)))"

# C. 局部区域亮度（定位缺的是哪层：整帧黑=截屏竞态；仅截图层黑=图片加载问题）
$FF -hide_banner -i video.mp4 -vf "select=eq(n\,703),crop=534:1156:273:330,signalstats,metadata=print:key=lavfi.signalstats.YAVG" -frames:v 1 -f null -
```

丢帧判据（实测标定）：

- **黑帧**：本帧均值 <20 且双邻帧 >25（合法内容帧不可能这么暗）
- **半帧**：本帧比双邻帧各暗 >12，且双邻帧亮度差 ≤8（排除平滑过渡/淡变动画）

## 4. 竞态闪帧修复管线（本机 macOS 12 + 旧 Chrome 实测最优）

1. **渲染**：`remotion render Main out/video.mp4 --crf=15 --x264-preset=slow --chrome-flag=--disable-gpu`
   （软件合成截帧最稳；不要用 `DISABLE_FROM_SURFACE`，见第 5 节）
2. **检出**：rawvideo 顺序扫描，按第 3 节判据列出全部丢帧
3. **修复**：抽全帧 PNG 序列 → 每个丢帧拷贝**前邻帧**覆盖（1/30s 冻结，内容近乎静止，不可感知）
4. **重编码**：CRF15/slow，音频 `-c:a copy` 原样拷贝
5. **复扫验证**：0 黑帧 0 半帧才交付；邮件小体积版复扫同样要过

参考实现：随本 skill 提供的 `scripts/repair-black-frames.py`（含 limited-range 阈值修正；ffmpeg 自动探测，可直接拷进任意 Remotion 项目使用）。

## 5. 已试无效 / 反而更糟的路（别再走）

| 方案 | 结果 |
|---|---|
| `DISABLE_FROM_SURFACE=1`（官方注释的缓解手段） | 本机 Chrome 上 `fromSurface:false` 与 `captureBeyondViewport:true` 不兼容，第 0 帧即 "Unable to capture screenshot" 崩溃 |
| Patch `screenshot-task.js`：近黑 JPEG(<30KB) 自动重试 | 黑帧归零，但 +80ms 重试落在**半绘制帧**（变暗 55%、JPEG >30KB 不再触发重试）→ 64 个半帧，比不补丁（9 个丢帧）更糟。**已回退** |
| 换 CRF / 码率 / x264 preset | 与截帧竞态无关，纯浪费渲染时间 |
| inline data URI + `background-image` 替代 `<Img>` | 黑帧从"很多"降到 3，未根除；但作为图片加载确定性化仍值得做（同时防 `<Img>` delayRender 竞态） |
| 只抽场景边界帧"看一眼" | 看不到随机闪，且 `-ss` 还晚 1 帧 → 连续四轮误报"已修复"的根因 |

## 6. 排查流程口诀

1. 用户报"闪" → **先量化**：全片逐帧扫描 + 定点复测，拿到异常帧号清单
2. **连渲两次**对帧号：变 → 竞态走第 4 节管线；不变 → 构图 bug 修代码
3. 修复后**复扫验证**，不信"看一眼"
4. 交付前邮件小体积版也要复扫（重编码不引入新问题）
