# Windows 渲染环境踩坑与解决方案

Remotion 在 Windows 上有几个"教科书级"的坑，第一次踩会卡很久。下面是在 Windows 11 + Node 22 上验证可行的配置。Mac / Linux 用户可直接跳过本文件。

## 1. CLI 入口不是 `remotion` 命令

安装后 `node_modules/.bin/remotion` 是 bash 脚本，Windows 直接 `node` 调不动。正确入口是：

```bash
node node_modules/@remotion/cli/remotion-cli.js <subcommand> <args>
```

例如：

```bash
node node_modules/@remotion/cli/remotion-cli.js compositions src/index.ts
node node_modules/@remotion/cli/remotion-cli.js render Main out/video.mp4
```

`npm run` / `npx remotion` 在部分环境也会失败，直接用上面的 `node ...remotion-cli.js` 最稳。

## 2. 用系统 Edge 替代 Chrome Headless Shell

Remotion 默认要下载 Chrome Headless Shell（约 113MB），在国内网络经常 `ECONNRESET` 中断，且中断后会残留 `download.lock` 导致反复失败。

解决方案：直接用系统已装的 **Edge（Chromium 内核）**。

- 固化进 `remotion.config.ts`：

```ts
import { Config } from '@remotion/cli/config';

Config.setBrowserExecutable(
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
);
```

- 或命令行指定：

```bash
node node_modules/@remotion/cli/remotion-cli.js render Main out/video.mp4 --browser-executable="C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe"
```

Edge 常见路径：`C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe` 或 `C:/Program Files/Microsoft/Edge/Application/msedge.exe`。找不到就 `where msedge`。

如果残留锁文件导致下载报错，手动删除：

```powershell
Remove-Item -Path "node_modules\.remotion\chrome-headless-shell\download.lock" -Force
```

## 3. ffmpeg 路径

Remotion 自带精简版 ffmpeg（位于 `node_modules/@remotion/compositor-win32-x64-msvc/ffmpeg.exe`），**但禁用了 `afade` / `aloop` / `concat` 等滤镜**。所以：

- 合成 BGM 不要用 ffmpeg 滤镜链，改用纯 Python（`scripts/make_bgm.py`）合成 PCM 再转码。
- 渲染 MP4 时让 Remotion 能找到这个 ffmpeg：把目录加进 `PATH`：

```bash
PATH="$PWD/node_modules/@remotion/compositor-win64-msvc:$PATH" node node_modules/@remotion/cli/remotion-cli.js render Main out/video.mp4
```

（实际目录名是 `compositor-win32-x64-msvc`，注意不是 `ffmpeg-win32`。）

抽帧检查也用它：

```bash
node_modules/@remotion/compositor-win32-x64-msvc/ffmpeg.exe -ss 8 -i out/video.mp4 -frames:v 1 frame.jpg
```

## 4. npm registry 连通性

先测网络再装：

```bash
npm view remotion version
```

把返回的版本号（如 `4.0.519`）写死进 `package.json`，避免 `^` 拉到不兼容版本。安装：

```bash
npm install
```

## 5. safe-delete 拦截文件操作

WorkBuddy 的 `safe-delete` 机制会把 git-bash 的 `rm 相对路径` 转成 `\c\...` 绝对路径然后判定失败（"relative path rejected"）。所以在 Windows 上：

- **删除 / 移动文件用 PowerShell 绝对路径**，不要 `git-bash rm`：

```powershell
Remove-Item -Path "C:\Users\you\project\out\old.mp4" -Force
Move-Item -Path "C:\Users\you\project\out\v2.mp4" -Destination "C:\Users\you\project\out\video.mp4"
```

- 替换渲染输出时，如果 `remotion-cli.js` 因 safe-delete 拦截无法覆盖旧文件，换个新文件名渲染（如 `out/v2.mp4`），再用 PowerShell `Move-Item` 覆盖。

## 6. 渲染命令模板（Windows 完整版）

```bash
cd <项目目录>
PATH="$PWD/node_modules/@remotion/compositor-win32-x64-msvc:$PATH" `
node node_modules/@remotion/cli/remotion-cli.js render Main out/video.mp4 --log=info
```

- 先渲 30 帧小样验证整条链路：`--frames=0-29`
- 长视频后台跑，日志落盘：`> render.log 2>&1`
- 并发：`--concurrency=4`

## 7. 其他

- 中文渲染：优先 `Microsoft YaHei` / `PingFang SC` 系统字体，避免缺字框。
- 依赖体积：安装后 `node_modules` 约 150+ 包，首次 `npm install` 较慢，耐心等。
- Chrome 下载残留的 `download.lock`：删了也不必重下，因为用的是 Edge。
