---
name: remotion-shortvideo
version: 1.1.0
display_name: "代码驱动短视频生成器"
display_name_en: "Remotion Short Video Generator"
description: 把一段脚本、要点清单或一张图，用 Remotion 框架生成竖屏/横屏科普宣传短视频（MP4）。当用户想把文字、要点或素材做成代码驱动的可编辑视频时使用，覆盖场景规划、React+TypeScript 场景组件、免费占位 BGM 合成、无头渲染全流程。触发词：做成视频、把这张图做成视频、用 Remotion 生成短视频、讲解 X 做成一个 60 秒短片、代码驱动视频生成。
description_zh: 把一段脚本、要点清单或一张图，用 Remotion 框架生成竖屏或横屏的科普宣传短视频（MP4）。覆盖场景规划、React+TypeScript 场景组件、免费占位 BGM 合成、无头渲染全流程，适合科普宣传、政策通知、安全提醒、产品演示、活动回顾类短视频。
description_en: Turn a script, bullet list, or image into a code-driven, editable short video (MP4) with the Remotion framework. Covers scene planning, React + TypeScript scene components, royalty-free placeholder BGM synthesis, and headless rendering — ideal for science-popularization, policy notices, safety reminders, product demos, and event recaps.
---

# Remotion Shortvideo（代码驱动短视频生成）

## Overview

把"主题 / 文案 / 图片素材"变成"可编辑的 Remotion 项目 + 渲染出的 MP4"。视频由 React + TypeScript 组件驱动，改文案、配色、时长只需改代码重渲，不依赖剪辑软件。适合科普宣传、政策通知、安全提醒、产品演示、活动回顾、知识讲解类短视频。

## When to use

- 用户给一段文字 / 要点清单 / 一张图，说"做成视频""做成短视频""讲成短片"
- 需要可程序化、可批量、可改文案复用的视频，而不是一次性手动剪辑
- 投放平台决定了尺寸：抖音 / 快手 / 视频号用竖屏 9:16，LED 大屏 / 电视用横屏 16:9，朋友圈用 1:1

## Workflow

### Step 0 需求澄清（先对齐再动手）

向用户确认五件事：① 投放平台与尺寸 ② 时长（建议 30–90s）③ 受众（决定语气，村民 / 干部 / 公众）④ 配乐调性 ⑤ 是否署名落款。竖屏默认 1080×1920 @ 30fps。

### Step 1 场景规划（脚本先于画面）

把内容拆成：开场（3–5s）+ N 个场景（每场景 3–8s）+ 收尾（4–6s）。单条文案 ≤ 40 字、手机小屏可读。输出一张分镜表（时间 / 画面 / 文案）让用户过目，再动手写代码。

### Step 2 搭脚手架

把 `assets/remotion-template.zip` 解压到目标工作区目录，再安装依赖：

```bash
# Windows (PowerShell):  Expand-Archive assets/remotion-template.zip -DestinationPath <目标目录>
# Mac / Linux:           unzip assets/remotion-template.zip -d <目标目录>
cd <目标目录>
npm install
```

依赖见 `package.json`：remotion 4.x、`@remotion/cli`、react 19、`lucide-react`（图标）。

### Step 3 填充内容（改两处即可）

1. `src/theme.ts`：调 `T`（场景时间轴，单位帧 @FPS）和配色 `C`（每个色都有注释说明用途，可整段替换成蓝 / 红主题而不动组件）。
2. `src/Video.tsx`：用 `<SceneTemplate .../>` 拼装场景，传 props 即可，无需新建组件文件：

   - 要点模式：`points=[{text, tone:'alert'|'safe'}]` → 渲染编号要点列表
   - 图标网格：`grid=[{icon, text}]` → 渲染 2×2 图示卡（适合"几种违法行为"一览）
   - 绿色提示框：`tip={{text, sub}}` → 正确做法 / 疏堵并用类正向提示
   - 底部强调条：`bottom="..."` → 画面收束金句
   - 场景标签：`tag="隐患一"` → 右上角警示胶囊

   `<Intro>`（开场标题）和 `<Outro>`（收尾标题 + 可开关署名）也吃 props。

### Step 4 BGM

- 默认方案：运行 `python scripts/make_bgm.py --duration 60 --style festive --bpm 120 --out public/bgm.mp3`，纯 Python 合成喜庆轻快占位乐并自动转 MP3（无需联网、无版权风险）。
- 或把正版商用 MP3 直接放进 `public/bgm.mp3`（Pixabay Music / YouTube Audio Library 等免费源）。
- 音量在 `src/Video.tsx` 的 `<Audio volume={0.62} />` 调。
- 关键开关：模板 `src/Video.tsx` 顶部 `const WITH_BGM = false` 默认静音（不生成 BGM 也能直接出片）。放入 `public/bgm.mp3` 后，把该值改为 `true` 才会真正播放配乐。

### Step 5 渲染

Windows 用户**务必先读 `references/windows-setup.md`**（Edge 替代 Chrome、内置 ffmpeg 路径、CLI 入口、safe-delete 规避），否则会卡在下载 Chrome 和找不到 bin 上。

通用渲染命令：

```bash
node node_modules/@remotion/cli/remotion-cli.js render Main out/video.mp4
```

Mac / Linux 用系统 Chrome，无需特殊配置。先渲 30 帧小样（`--frames=0-29`）验证整条链路，再渲全片。

### Step 6 校验

抽帧检查内容问题（文字遮挡、字号、节奏对口）。**注意：`ffmpeg -ss <秒>` 时间定位取帧会系统性晚 1 帧，定点复测必须用 `select=eq(n,帧号)`。** 若用户反馈"闪/黑帧"，**不要凭单帧抽样判断**——先读 `references/black-frame-debugging.md`，用全片逐帧亮度扫描定位异常帧号，连渲两次区分"确定性构图 bug"（帧号不变→改代码）与"Chrome 截帧竞态"（帧号每次不同→渲染加 `--chrome-flag=--disable-gpu` + 后期丢帧修复管线），修复后复扫验证再交付。

## Resources

- `assets/remotion-template.zip` — 完整可运行 Remotion 项目（不含 node_modules），解压即用
- `scripts/make_bgm.py` — 参数化占位 BGM 合成（PCM → WAV → MP3）
- `scripts/repair-black-frames.py` — 渲染后孤立黑帧/半帧检测与邻帧替换修复（ffmpeg 自动探测，零配置）
- `references/windows-setup.md` — Windows 渲染环境踩坑与解决方案
- `references/black-frame-debugging.md` — 闪屏/黑帧排查手册（帧级取证方法、三类验证工具坑、截帧竞态修复管线、无效方案清单）

## 注意事项

- 版权：BGM / 图片 / 字体一律用免费商用源，避免侵权；内置 BGM 为程序化合成无版权风险
- 文字即成本：视频里错别字修改成本极高，输出前反复校对文案
- 尺寸适配：提前问清平台，9:16 / 1:1 / 16:9 要对应不同画布
- 输出格式：默认 MP4 H.264；需要 MOV / WebM 单独说明
- 替换提示：内置 BGM 音色偏"玩具盒"，正式投放建议用正版丰收 / 科普主题音乐替换
- 闪屏先量化后动手：用户报"闪"时第一动作是全片逐帧扫描取证（见 `references/black-frame-debugging.md`），切勿凭边界抽帧"看一眼"就下结论——单帧抽样 + `-ss` 晚 1 帧会制造连续多轮"已修复"的误报
