# -*- coding: utf-8 -*-
"""
通用占位 BGM 合成器（Remotion 短视频）
纯 Python 合成 PCM -> WAV，再调用 ffmpeg 转 MP3。
无版权风险，可作为临时配乐；正式投放建议替换为正版商用音乐。

用法:
  python make_bgm.py --duration 60 --style festive --bpm 120 --out public/bgm.mp3
  python make_bgm.py --duration 30 --style calm
  python make_bgm.py --style upbeat --bpm 128

参数:
  --duration  时长(秒)，默认 60
  --style     festive(喜庆丰收/C大调五声, 默认) | calm(舒缓叙事) | upbeat(电子轻快)
  --bpm       节拍速度，默认取 style 预设
  --out       输出 mp3 路径，默认 public/bgm.mp3

依赖:
  - 仅标准库合成 WAV
  - 转 MP3 需要 ffmpeg（自动探测 node_modules 内置版或系统 PATH 中的 ffmpeg）
"""
import argparse
import math
import os
import random
import shutil
import struct
import subprocess
import wave

SR = 44100

# 音名 -> 频率(Hz)
F = {
    'C2': 65.41, 'D2': 73.42, 'E2': 82.41, 'F2': 87.31, 'G2': 98.00, 'A2': 110.00,
    'C3': 130.81, 'E3': 164.81, 'F3': 174.61, 'G3': 196.00, 'A3': 220.00,
    'C4': 261.63, 'D4': 293.66, 'E4': 329.63, 'F4': 349.23, 'G4': 392.00, 'A4': 440.00,
    'C5': 523.25, 'D5': 587.33, 'E5': 659.25, 'G5': 783.99, 'A5': 880.00,
}

# 三种风格预设
STYLES = {
    'festive': dict(
        bpm=120,
        scale=['G4', 'A4', 'C5', 'D5', 'E5', 'D5', 'C5', 'A4',
               'G4', 'C5', 'D5', 'E5', 'G5', 'E5', 'D5', 'C5'],
        bass=['C3', 'C3', 'G2', 'G2', 'A2', 'A2', 'G2', 'G2'],
        amp_mel=0.26, amp_bass=0.40, amp_hat=0.045, amp_snare=0.13,
        fade_in=1.5, fade_out=3.0,
    ),
    'calm': dict(
        bpm=84,
        scale=['C4', 'E4', 'G4', 'E4', 'A4', 'G4', 'E4', 'C4',
               'D4', 'F4', 'A4', 'F4', 'G4', 'E4', 'C4', 'G3'],
        bass=['C3', 'C3', 'A2', 'A2', 'F2', 'F2', 'G2', 'G2'],
        amp_mel=0.20, amp_bass=0.30, amp_hat=0.020, amp_snare=0.0,
        fade_in=2.5, fade_out=4.0,
    ),
    'upbeat': dict(
        bpm=128,
        scale=['E4', 'G4', 'A4', 'B4', 'A4', 'G4', 'E4', 'D4',
               'E4', 'A4', 'B4', 'C5', 'B4', 'A4', 'G4', 'E4'],
        bass=['A2', 'A2', 'E2', 'E2', 'F2', 'F2', 'G2', 'G2'],
        amp_mel=0.24, amp_bass=0.42, amp_hat=0.060, amp_snare=0.16,
        fade_in=0.8, fade_out=2.0,
    ),
}


def envelope(i, dur, sr=SR):
    """5ms 起音 + 指数衰减，避免爆音"""
    a = int(0.005 * sr)
    if i < a:
        return i / a
    t = (i - a) / sr
    d = max(dur - 0.005, 0.01)
    return math.exp(-3.0 * t / d)


def synth(duration, bpm, cfg, seed=20260901):
    n = int(SR * duration)
    beat = 60.0 / bpm
    buf = [0.0] * n
    random.seed(seed)
    two_pi = 2 * math.pi

    def add_tone(start, freq, dur, amp, timbre='sine'):
        s = int(start * SR)
        nn = int(dur * SR)
        for i in range(nn):
            idx = s + i
            if idx >= n:
                break
            ph = two_pi * freq * (i / SR)
            if timbre == 'pluck':
                v = math.sin(ph) + 0.40 * math.sin(2 * ph) + 0.15 * math.sin(3 * ph)
            elif timbre == 'bass':
                v = 0.80 * math.sin(ph) + 0.20 * math.sin(2 * ph)
            else:
                v = math.sin(ph)
            buf[idx] += v * amp * envelope(i, dur)

    def add_noise(start, dur, amp):
        s = int(start * SR)
        nn = int(dur * SR)
        for i in range(nn):
            idx = s + i
            if idx >= n:
                break
            buf[idx] += (random.random() * 2 - 1) * amp * envelope(i, dur)

    cycle_beats = 16
    cycle_dur = cycle_beats * beat
    n_cycles = int(duration / cycle_dur) + 1
    for c in range(n_cycles):
        base = c * cycle_dur
        if base >= duration:
            break
        for b in range(cycle_beats):
            t = base + b * beat
            if t >= duration:
                break
            add_tone(t, F[cfg['scale'][b % len(cfg['scale'])]], beat * 0.85,
                     cfg['amp_mel'], 'pluck')
            add_tone(t, 90.0, 0.16, cfg['amp_bass'], 'bass')
            add_noise(t + beat * 0.5, 0.05, cfg['amp_hat'])
            if b % 4 == 2 and cfg['amp_snare'] > 0:
                add_noise(t, 0.12, cfg['amp_snare'])
        for bi, bn in enumerate(cfg['bass']):
            t = base + bi * 2 * beat
            if t >= duration:
                break
            add_tone(t, F[bn], beat * 1.7, 0.28, 'bass')

    fi = int(cfg['fade_in'] * SR)
    fo = int(cfg['fade_out'] * SR)
    for i in range(n):
        if i < fi:
            buf[i] *= i / fi
        if i > n - fo:
            buf[i] *= max(0.0, (n - i) / fo)

    peak = max(abs(x) for x in buf) or 1.0
    gain = 0.82 / peak
    return buf, gain


def write_wav(path, buf, gain):
    with wave.open(path, 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        frames = bytearray()
        for v in buf:
            s = int(max(-1.0, min(1.0, v * gain)) * 32767)
            frames += struct.pack('<h', s)
        w.writeframes(bytes(frames))


def find_ffmpeg():
    cand = [
        'node_modules/@remotion/compositor-win32-x64-msvc/ffmpeg.exe',
        'node_modules/@remotion/compositor-win64-msvc/ffmpeg.exe',
    ]
    for c in cand:
        if os.path.exists(c):
            return c
    return shutil.which('ffmpeg')


def to_mp3(wav_path, mp3_path):
    ff = find_ffmpeg()
    if not ff:
        print('[warn] 未找到 ffmpeg，仅保留 WAV：%s' % wav_path)
        print('        手动转 MP3: ffmpeg -i %s -c:a libmp3lame -b:a 128k %s'
              % (wav_path, mp3_path))
        return False
    try:
        subprocess.run([ff, '-y', '-hide_banner', '-loglevel', 'error',
                        '-i', wav_path, '-c:a', 'libmp3lame', '-b:a', '128k',
                        mp3_path], check=True)
        return True
    except subprocess.CalledProcessError as e:
        print('[warn] ffmpeg 转码失败: %s' % e)
        return False


def main():
    ap = argparse.ArgumentParser(description='占位 BGM 合成器')
    ap.add_argument('--duration', type=float, default=60.0)
    ap.add_argument('--style', default='festive',
                    choices=list(STYLES.keys()))
    ap.add_argument('--bpm', type=float, default=None)
    ap.add_argument('--out', default='public/bgm.mp3')
    args = ap.parse_args()

    cfg = dict(STYLES[args.style])
    bpm = args.bpm or cfg['bpm']

    buf, gain = synth(args.duration, bpm, cfg)
    out_dir = os.path.dirname(os.path.abspath(args.out))
    os.makedirs(out_dir, exist_ok=True)
    wav_path = os.path.splitext(args.out)[0] + '.wav'
    write_wav(wav_path, buf, gain)
    print('OK WAV: %s  (%.1fs, %d samples)' % (wav_path, args.duration, len(buf)))

    if to_mp3(wav_path, args.out):
        try:
            os.remove(wav_path)
        except OSError:
            pass
        print('OK MP3: %s' % args.out)
    else:
        print('请手动把 WAV 转成 MP3: %s' % wav_path)


if __name__ == '__main__':
    main()
