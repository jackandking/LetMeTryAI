#!/usr/bin/env python3
"""Repair isolated black frames in a rendered Remotion video.

Root cause being repaired: headless Chrome's Page.captureScreenshot
occasionally (~0.3% of frames) grabs the surface before the page paints,
yielding a fully black frame. Such dropouts are isolated single frames
whose neighbors are normal. This is a known Remotion issue (see
`screenshot-task.js`: "0.1% framedrop when rendering under memory
pressure"); it is non-deterministic, so the dropped frame numbers
differ on every render.

Repair: replace each black frame with the previous frame's pixels
(content is near-static across 1/30s, so the swap is imperceptible).
Frames are round-tripped through PNG (lossless), then re-encoded with
CRF15/slow; audio is stream-copied.

Usage:
    python3 repair-black-frames.py INPUT.mp4 [OUTPUT.mp4]

ffmpeg resolution order: $FFMPEG env > PATH > Remotion's bundled
compositor binary (macOS/Linux) > system ffmpeg.
"""
import os
import shutil
import subprocess
import sys
import tempfile


def find_ffmpeg():
    """Locate an ffmpeg binary without hardcoding project paths."""
    env = os.environ.get("FFMPEG")
    if env and os.path.isfile(env):
        return env
    found = shutil.which("ffmpeg")
    if found:
        return found
    # Remotion ships platform compositor binaries inside node_modules
    here = os.getcwd()
    candidates = [
        os.path.join(here, "node_modules/@remotion/compositor-darwin-x64/ffmpeg"),
        os.path.join(here, "node_modules/@remotion/compositor-linux-x64/ffmpeg"),
        os.path.join(here, "node_modules/@remotion/compositor-darwin-arm64/ffmpeg"),
        "/usr/bin/ffmpeg",
        "/usr/local/bin/ffmpeg",
    ]
    for c in candidates:
        if os.path.isfile(c):
            return c
    sys.exit("[error] no ffmpeg found: set FFMPEG env or install ffmpeg")


FF = find_ffmpeg()


def scan(video, w=32):
    """Return (dropouts, n_frames, means) using sequential rawvideo scan.

    A dropout is an isolated frame that is abnormally dark compared to BOTH
    neighbors while the neighbors match each other (i.e. a paint race, not a
    smooth animation ramp). Two severities are caught:
      - full black:  luma < 20 with lit neighbors (>25)
        (video is limited-range YUV: pure black reads as ~16, not 0,
        when tagged gray via format=gray without range expansion)
      - half-painted: luma < neighbor - 12 (neighbors within 8 of each other)
    """
    raw = subprocess.run(
        [FF, "-hide_banner", "-i", video, "-vf", f"scale={w}:{w},format=gray",
         "-pix_fmt", "gray", "-f", "rawvideo", "-"],
        capture_output=True, check=True,
    ).stdout
    fr = w * w
    n = len(raw) // fr
    means = [sum(raw[i * fr:(i + 1) * fr]) / fr for i in range(n)]
    drops = []
    for i in range(1, n - 1):
        prev_, next_ = means[i - 1], means[i + 1]
        if means[i] < 20 and prev_ > 25 and next_ > 25:
            drops.append(i)  # full black (also at scene boundaries)
        elif (abs(prev_ - next_) <= 8 and means[i] < prev_ - 12
              and means[i] < next_ - 12):
            drops.append(i)  # half-painted dim frame
    return drops, n, means


def repair(video, out, drops):
    frame_dir = tempfile.mkdtemp(prefix="remotion_repair_")
    try:
        print(f"[repair] extracting frames from {video} ...")
        subprocess.run(
            [FF, "-hide_banner", "-i", video, "-vsync", "0",
             f"{frame_dir}/f_%05d.png", "-y"],
            check=True,
        )
        for d in drops:
            # PNG 序列从 1 编号：0 基帧号 i -> 文件 i+1；前一帧 -> 文件 i
            src = f"{frame_dir}/f_{d:05d}.png"
            dst = f"{frame_dir}/f_{d + 1:05d}.png"
            shutil.copyfile(src, dst)  # previous frame may itself be repaired
            print(f"[repair] frame {d} <- frame {d - 1}")
        print(f"[repair] re-encoding {out} ...")
        subprocess.run(
            [FF, "-hide_banner", "-y",
             "-framerate", "30", "-i", f"{frame_dir}/f_%05d.png",
             "-i", video,
             "-map", "0:v", "-map", "1:a?",
             "-c:v", "libx264", "-crf", "15", "-preset", "slow",
             "-pix_fmt", "yuv420p", "-c:a", "copy",
             out],
            check=True,
        )
    finally:
        shutil.rmtree(frame_dir, ignore_errors=True)


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    video = sys.argv[1]
    out = sys.argv[2] if len(sys.argv) > 2 else video.replace(".mp4", "-fixed.mp4")
    drops, n, means = scan(video)
    print(f"[scan] {video}: {n} frames, min luma {min(means):.2f}")
    if not drops:
        print("[scan] CLEAN - no isolated black frames.")
        return
    print(f"[scan] {len(drops)} isolated black frame(s): {drops}")
    repair(video, out, drops)
    d2, n2, m2 = scan(out)
    if d2:
        print(f"[verify] STILL DIRTY: {d2}")
        sys.exit(1)
    print(f"[verify] CLEAN - {out} has 0 isolated black frames.")


if __name__ == "__main__":
    main()
